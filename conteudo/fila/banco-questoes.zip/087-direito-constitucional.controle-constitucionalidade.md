Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Direito Constitucional: Controle de constitucionalidade** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 2 lotes de 50 questões, um por resposta. Quando eu pedir "lote 1", entregue o lote 1; quando eu pedir "lote 2", entregue o lote 2, sem repetir casos do lote 1.

## Escopo
Inconstitucionalidade formal e material; controle preventivo e repressivo; controle difuso, cláusula de reserva de plenário e papel do Senado; controle concentrado por ADI, ADC, ADO e ADPF, com legitimados, efeitos e modulação.
Fica de fora (outras matérias tratam): Controle de constitucionalidade estadual em face de constituições estaduais, controle de convencionalidade e ações constitucionais que não integrem o escopo do lote.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Ação direta de inconstitucionalidade.
- Controle de Constitucionalidade.
- Ação declaratória de constitucionalidade.
- Arguição de descumprimento de preceito fundamental.
- Controle de constitucionalidade: sistemas difuso e concentrado.
- Ação Direta de Inconstitucionalidade por Omissão.
- Ação declaratória de constitucionalidade e arguição de descumprimento de preceito fundamental.
- Controle de constitucionalidade de atos normativos.
- Controle da constitucionalidade: Sistemas gerais e sistema brasileiro.
- Controle abstrato de constitucionalidade.
- Controle concreto e abstrato de constitucionalidade do direito municipal.
- Controle de constitucionalidade: sistemas gerais e sistema brasileiro.
- Controle de constitucionalidade nos estados e no Distrito Federal.
- Constituição: Supremacia da Constituição.
- Controle da constitucionalidade: Controle incidental ou concreto.
- Controle da constitucionalidade: Controle abstrato de constitucionalidade.
- Controle da constitucionalidade: Ação declaratória de constitucionalidade.
- Controle da constitucionalidade: Ação direta de inconstitucionalidade.
- Controle judicial de constitucionalidade: conceito, histórico, sistemas, pressupostos, modalidades, órgãos competentes, sujeitos legitimados, objetos de controle, tipos de inconstitucionalidade, parâmetros de controle, formalidades, procedimentos, julgamentos, decisões, efeitos das decisões, técnicas de decisão, segurança e estabilidade das decisões.
- Controle não judicial de constitucionalidade: órgãos, institutos e procedimentos.
- Interpretação da Constituição e controle de constitucionalidade; normas constitucionais e inconstitucionais.
- Incidente de arguição de inconstitucionalidade.
- Controle incidental ou concreto.
- Exame in abstractu da constitucionalidade de proposições legislativas.
- Ação direta de inconstitucionalidade por ação e por omissão.
- Controle de constitucionalidade: ação direta de inconstitucionalidade.
- Controle da constitucionalidade: Exame in abstractu da constitucionalidade de proposições legislativas.
- Controle da constitucionalidade: Arguição de descumprimento de preceito fundamental.
- Controle da constitucionalidade: Ação direta de inconstitucionalidade por omissão.
- Controle da constitucionalidade: Ação direta de inconstitucionalidade interventiva.

## Cada lote de 50
- 25 de múltipla escolha A a E (5 alternativas), 13 de múltipla escolha A a D (4 alternativas), 12 de Certo/Errado.
- Dificuldade: 15 fáceis, 20 médias, 15 difíceis. Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, literalidade da lei com o detalhe que a prova troca, jurisprudência e súmulas, comparação entre conceitos parecidos. Use casos DIFERENTES entre si; nada de repetir o mesmo caso com outras palavras.

## Regras de qualidade
1. Cite artigo, lei, súmula e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Se não tiver certeza de um número, explique sem ele — nunca invente.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Explicação (mínimo 120 caracteres): por que a certa está certa e por que CADA errada erra, com o conceito específico. Em Certo/Errado começa com "Certo." ou "Errado.". Escreva cada explicação de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo direito-constitucional.controle-constitucionalidade.banco-N.json, onde N é o lote)
```json
{
  "materia": "direito-constitucional.controle-constitucionalidade",
  "lote": 1,
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false }, { "key": "B", "text": "...", "correct": true } ],
      "explanation": "..." }
  ]
}
```
- format: "MULTIPLE_CHOICE" (A–E com 5 opções ou A–D com 4 opções) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
