Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Língua Portuguesa: Termos da oração** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 2 lotes de 50 questões, um por resposta. Quando eu pedir "lote 1", entregue o lote 1; quando eu pedir "lote 2", entregue o lote 2, sem repetir casos do lote 1.

## Escopo
Identificação e análise do sujeito e do predicado, objetos direto e indireto, complemento nominal, adjuntos adnominal e adverbial, predicativo, aposto e vocativo, com distinção entre termos ligados ao verbo, ao nome e à oração.
Fica de fora (outras matérias tratam): Período composto em profundidade, classificação completa das orações subordinadas e estudo isolado da regência verbal e nominal.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Organização sintática das frases: termos e orações.
- Morfossintaxe.
- Sintaxe.
- Ordem direta e inversa.
- Termos da oração.
- Sintaxe: termos da oração e relações sintático-semânticas estabelecidas entre termos, orações, períodos ou parágrafos (período simples e período composto por coordenação e por subordinação).
- Análise morfossintática.
- Organização sintática, termos e orações e ordem direta e inversa.
- Termos essenciais, integrantes e acessórios da oração e vocativo.
- Termos da oração, vocativo, crase e pronomes: emprego, formas de tratamento e colocação.
- Sintaxe: funções sintáticas e suas relações no período simples e no período composto.
- Sintaxe e construção frasal.
- Organização sintática das frases: termos e orações; ordem direta e inversa.
- Análise sintática: termos essenciais, integrantes e acessórios da oração.
- Termos essenciais, integrantes e acessórios da oração, vocativo e crase.
- Termos essenciais, integrantes e acessórios da oração, vocativo, crase e pronomes.
- Sintaxe: funções sintáticas e suas relações nos períodos simples e compostos.
- Língua portuguesa: modalidade culta usada contemporaneamente no Brasil: Morfossintaxe.
- Sintaxe: termos essenciais, integrantes e acessórios da oração.
- Sintaxe: reconhecimento dos termos da oração.
- Análise morfossintática de período simples.
- Funções sintáticas.
- Termos e orações e ordem direta e inversa.
- Termos da oração e relações sintático-semânticas entre orações, períodos e parágrafos.
- Textos da esfera jornalística/publicitária — Análise linguística: Analise a estruturação sintática de sentenças nos textos, observando como a ordem dos termos (sujeito, verbo, complemento) reflete o foco jornalístico (em manchetes, por exemplo).

## Cada lote de 50
- 25 de múltipla escolha A a E (5 alternativas), 13 de múltipla escolha A a D (4 alternativas), 12 de Certo/Errado.
- Dificuldade: 15 fáceis, 20 médias, 15 difíceis. Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, comparação entre conceitos parecidos. Use casos DIFERENTES entre si; nada de repetir o mesmo caso com outras palavras.

## Regras de qualidade
1. Regra precisa, com exemplos concretos; nunca invente regra ou dado.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Explicação (mínimo 120 caracteres): por que a certa está certa e por que CADA errada erra, com o conceito específico. Em Certo/Errado começa com "Certo." ou "Errado.". Escreva cada explicação de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo portugues.termos-da-oracao.banco-N.json, onde N é o lote)
```json
{
  "materia": "portugues.termos-da-oracao",
  "lote": 1,
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false }, { "key": "B", "text": "...", "correct": true } ],
      "explanation": "..." }
  ]
}
```
- format: "MULTIPLE_CHOICE" (A–E com 5 opções ou A–D com 4 opções) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
