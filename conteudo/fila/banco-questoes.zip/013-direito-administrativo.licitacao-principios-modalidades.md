Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Direito Administrativo: Licitação na Lei 14.133/2021: conceito, princípios e modalidades** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 5 lotes, um por resposta. Quando eu pedir 'lote N', entregue só aquele lote, sem repetir casos dos lotes anteriores:
- **Lote 1 (CEBRASPE, 50 questões):** 50 itens de Certo/Errado no estilo Cebraspe: afirmação curta e técnica, com o detalhe trocado (prazo, competência, exceção, conceito vizinho); explanation começa com Certo. ou Errado. Como na prova, cerca de 20 dos 50 itens vêm em 4 grupos de 5 itens sobre um mesmo texto ou situação hipotética mais longa (8 a 15 linhas); repita esse texto completo no statement de cada item do grupo, para cada item funcionar sozinho.
- **Lote 2 (CEBRASPE, 50 questões):** mais 50 itens de Certo/Errado no estilo Cebraspe, cobrindo outros pontos e casos que o lote 1, também com cerca de 20 itens em 4 grupos de 5 sobre um texto ou situação comum (repetido no statement de cada item).
- **Lote 3 (FGV, 30 questões):** 30 de múltipla escolha A a E no estilo FGV: caso concreto mais longo, aplicação e interpretação; as erradas são aplicações plausíveis mas equivocadas.
- **Lote 4 (FCC, 30 questões):** 30 de múltipla escolha A a E no estilo FCC: mais literal, cobra o texto da norma/regra com o detalhe de prazo, número, competência ou exceção.
- **Lote 5 (CESGRANRIO, 30 questões):** 30 de múltipla escolha A a E no estilo Cesgranrio, FUMARC, IDECAN, IBFC e bancas de nível médio: enunciado curto e direto, uma regra por questão.

## Escopo
Conceito e objetivos do processo licitatório; princípios expressos do art. 5º; agentes de contratação e segregação de funções; cinco modalidades; seis critérios de julgamento; rito e modos de disputa em visão geral; procedimentos auxiliares da Lei nº 14.133/2021, inclusive alterações vigentes.
Fica de fora (outras matérias tratam): Hipóteses detalhadas de dispensa e inexigibilidade, fases e recursos aprofundados, regime de contratos administrativos e sanções, orçamento e planejamento aprofundado, assuntos examinados em tópicos próprios.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Licitação.
- Licitação: modalidades.
- Licitação: Princípios.
- Modalidades.
- Licitação: Tipos.
- Nova Lei de Licitações e Contratos da Administração Pública (Lei n. 14.133/2021).
- Licitações e Contratos administrativos.
- Legislação aplicável à contratação de bens e serviços: Lei nº 14.133/2021.
- Princípios básicos e correlatos.
- Legislação aplicável à contratação de bens e serviços.
- Normas gerais de licitação.
- Licitações.
- Legislação pertinente: Decreto nº 11.462/2023.
- Licitação: conceito, natureza jurídica, objeto e finalidade.
- Licitações: modalidades e procedimentos.
- Licitações e contratos administrativos: Legislação pertinente.
- Legislação pertinente: Lei nº 14.133/2021.
- Legislação pertinente: Lei nº 14.133/2021 e suas alterações.
- Licitação: conceito, finalidades, princípios e objeto.
- Lei nº 8.666/1993, Lei nº 14.133/2021.
- Licitação: princípios, contratação direta, dispensa, inexigibilidade, modalidades, tipos e procedimento.
- Lei nº 14.133/2021 e suas alterações.
- Licitações e contratos administrativos: Lei nº 14.133/2021 e suas alterações.
- Conceito, natureza jurídica, objeto e finalidade.
- Lei nº 14.133/2021 e alterações.
- Pregão.
- Licitação Pública: conceito, princípios, finalidade do procedimento licitatório, modalidades, dispensa e inexigibilidade de licitação.
- Licitações e contratos administrativos: conceito, finalidades, princípios, objeto e normas gerais, especialmente as Leis nº 8.666/1993 e nº 14.133/2021.
- Registro de preços.
- Licitações e contratos administrativos. Lei nº 14.133/2021 (Nova Lei de Licitações e Contratos Administrativos).

## Em todos os lotes
- Dificuldade: 25% fáceis, 35% médias, 40% difíceis ("difficulty": FACIL, MEDIA, DIFICIL), seguindo estas definições:
  - **FACIL:** cobra a regra principal como está na lei ou no conceito; acerta quem leu a matéria uma vez.
  - **MEDIA:** aplica a regra a um caso concreto ou cobra um detalhe (prazo, competência, exceção); exige estudo atento.
  - **DIFICIL:** combina duas ou mais regras, cobra a exceção da exceção, jurisprudência que contraria a leitura literal, ou monta caso em que a resposta intuitiva está errada; erra quem estudou só o básico. Distratores das difíceis são quase certos (diferem num detalhe decisivo). Técnicas para o difícil: trocar UMA palavra decisiva ("pode"/"deve", "apenas"/"também", "e"/"ou", prazo, competência); afirmação quase toda correta com um único desvio no fim; inferência que parece óbvia mas o texto/norma não autoriza; generalização de uma exceção; inversão de causa e consequência; regra certa aplicada à hipótese errada.
  - A dificuldade vem do raciocínio exigido, NUNCA do tamanho do texto: questão difícil pode ser curta, e enunciado longo não torna a questão difícil.
- Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, literalidade da lei com o detalhe que a prova troca, jurisprudência e súmulas, comparação entre conceitos parecidos. Casos DIFERENTES entre si e entre lotes; nada de repetir o mesmo caso com outras palavras.
- Nos lotes de múltipla escolha (FGV, FCC, CESGRANRIO), varie o comando como nas provas: cerca de 65% "assinale a correta"; cerca de 20% "assinale a INCORRETA" (o comando deixa isso explícito em maiúsculas e só uma alternativa é falsa); cerca de 15% de assertivas — o enunciado traz itens I, II, III e IV (às vezes V) e as alternativas são combinações ("Apenas I e II.", "Apenas II, III e IV." etc.), com uma única combinação certa; nas assertivas, o comentário de cada alternativa diz quais itens são verdadeiros ou falsos e por quê.
- Cada questão leva "estilo" com o nome do estilo do lote (CEBRASPE, FGV, FCC, CESGRANRIO).

## Regras de qualidade
1. Cite artigo, lei, súmula e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Se não tiver certeza de um número, explique sem ele — nunca invente.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Em Certo/Errado, as duas opções NÃO levam "comentario" (só a explanation). Em múltipla escolha: cada alternativa tem "comentario" próprio (1–2 frases: por que está certa ou, se errada, qual o erro específico) e a "explanation" geral (mínimo 80 caracteres) explica a regra/conceito **sem citar letras** (nada de "A", "B", "alternativa C"). Em Certo/Errado a explanation começa com "Certo." ou "Errado." e explica o item (mínimo 120 caracteres). Cada texto escrito de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo direito-administrativo.licitacao-principios-modalidades.banco-N.json, onde N é o lote)
```json
{
  "materia": "direito-administrativo.licitacao-principios-modalidades",
  "lote": 1,
  "estilo": "CEBRASPE",
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "estilo": "CEBRASPE", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false, "comentario": "erro específico desta alternativa" }, { "key": "B", "text": "...", "correct": true, "comentario": "por que está certa" } ],
      "explanation": "..." }
  ]
}
```
- format: "MULTIPLE_CHOICE" (sempre 5 opções A–E) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
