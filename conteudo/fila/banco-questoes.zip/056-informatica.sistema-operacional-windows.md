Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Noções de Informática: Sistema Operacional Windows 10** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 4 lotes, um por resposta. Quando eu pedir 'lote N', entregue só aquele lote, sem repetir casos dos lotes anteriores:
- **Lote 1 (CEBRASPE, 50 questões):** 50 itens de Certo/Errado no estilo Cebraspe: afirmação curta e técnica, com o detalhe trocado (prazo, competência, exceção, conceito vizinho); explanation começa com Certo. ou Errado. Como na prova, cerca de 20 dos 50 itens vêm em 4 grupos de 5 itens sobre um mesmo texto ou situação hipotética mais longa (8 a 15 linhas); repita esse texto completo no statement de cada item do grupo, para cada item funcionar sozinho.
- **Lote 2 (FGV, 40 questões):** 40 de múltipla escolha A a E no estilo FGV: caso concreto mais longo, aplicação e interpretação; as erradas são aplicações plausíveis mas equivocadas.
- **Lote 3 (FCC, 40 questões):** 40 de múltipla escolha A a E no estilo FCC: mais literal, cobra o texto da norma/regra com o detalhe de prazo, número, competência ou exceção.
- **Lote 4 (CESGRANRIO, 40 questões):** 40 de múltipla escolha A a E no estilo Cesgranrio, FUMARC, IDECAN, IBFC e bancas de nível médio: enunciado curto e direto, uma regra por questão.

## Escopo
Uso do Windows 10 em estação de trabalho: interface, janelas, Explorador de Arquivos, caminhos, busca, operações com arquivos e pastas, configurações usuais, extensões, compartilhamento e permissões.
Fica de fora (outras matérias tratam): Administração avançada de domínio, comandos de terminal, registro do Windows, políticas corporativas e recursos exclusivos do Windows 11.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Conceitos de organização e de gerenciamento de informações, arquivos, pastas e programas.
- Sistema Operacional Windows 10: manipulação de arquivos e pastas, configurações, permissões etc.
- Sistema operacional Windows.
- Noções de sistema operacional (ambiente Windows).
- Organização e gerenciamento de informações, arquivos, pastas e programas.
- Sistema operacional e ambiente Windows.
- Extensões e arquivos.
- Sistemas Operacionais Windows/Linux: conceito de pastas, diretórios, arquivos e atalhos.
- Área de trabalho e área de transferência.
- Manipulação de arquivos e pastas.
- Organização de informações, arquivos, pastas e programas.
- Organização de arquivos, pastas e programas.
- Noções de sistema operacional Windows.
- Noções de organização e de gerenciamento de informações, arquivos, pastas e programas.
- Identificação e manipulação de arquivos.
- Windows 10: janelas, menus, barra de tarefas, área de trabalho e gerenciamento de arquivos e pastas.
- Compartilhamento, área de transferência, configurações de tela, cores, fontes e impressoras; Windows Explorer.
- Sistema operacional Windows 10.
- Gerenciamento de arquivos, pastas e programas.
- Noções de sistema operacional no ambiente Windows.
- Identificação e manipulação de arquivos e backup.
- Noções de sistema operacional (Windows e Linux).
- Sistema Operacional: Windows/Linux: conceito de pastas, diretórios, arquivos e atalhos, área de trabalho, área de transferência, manipulação de arquivos e pastas, uso dos menus, programas e aplicativos, interação com o conjunto de aplicativos.
- Noções de sistema operacional (Linux e Windows).
- MS-Windows 10: arquivos, pastas, atalhos, área de trabalho, menus, programas e aplicativos.
- MS-Windows 10: pastas, diretórios, arquivos, atalhos, áreas de trabalho e transferência, manipulação de arquivos, menus, programas e aplicativos.
- Conceitos básicos do sistema operacional Windows.
- Principais aplicativos e acessórios do Windows 10.
- Conceitos de organização de pastas e arquivos.
- Principais extensões de arquivos.

## Em todos os lotes
- Dificuldade: 25% fáceis, 35% médias, 40% difíceis ("difficulty": FACIL, MEDIA, DIFICIL), seguindo estas definições:
  - **FACIL:** cobra a regra principal como está na lei ou no conceito; acerta quem leu a matéria uma vez.
  - **MEDIA:** aplica a regra a um caso concreto ou cobra um detalhe (prazo, competência, exceção); exige estudo atento.
  - **DIFICIL:** combina duas ou mais regras, cobra a exceção da exceção, jurisprudência que contraria a leitura literal, ou monta caso em que a resposta intuitiva está errada; erra quem estudou só o básico. Distratores das difíceis são quase certos (diferem num detalhe decisivo). Técnicas para o difícil: trocar UMA palavra decisiva ("pode"/"deve", "apenas"/"também", "e"/"ou", prazo, competência); afirmação quase toda correta com um único desvio no fim; inferência que parece óbvia mas o texto/norma não autoriza; generalização de uma exceção; inversão de causa e consequência; regra certa aplicada à hipótese errada.
  - Teste antes de marcar DIFICIL: se um candidato que estudou só o básico acertaria em poucos segundos, a questão é FACIL ou MEDIA — reclassifique ou torne-a mais exigente (ex.: em gramática, opor categorias vizinhas que se confundem de verdade, como coordenada explicativa x subordinada causal, "que" conjunção x pronome relativo, "onde" x "aonde"; em direito, regra x exceção x exceção da exceção).
  - A dificuldade vem do raciocínio exigido, NUNCA do tamanho do texto: questão difícil pode ser curta, e enunciado longo não torna a questão difícil.
- Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, comparação entre conceitos parecidos. Casos DIFERENTES entre si e entre lotes; nada de repetir o mesmo caso com outras palavras.
- Nos lotes de múltipla escolha (FGV, FCC, CESGRANRIO), varie o comando como nas provas: cerca de 65% "assinale a correta"; cerca de 20% "assinale a INCORRETA" (o comando deixa isso explícito em maiúsculas e só uma alternativa é falsa); cerca de 15% de assertivas — o enunciado traz itens I, II, III e IV (às vezes V) e as alternativas são combinações ("Apenas I e II.", "Apenas II, III e IV." etc.), com uma única combinação certa; nas assertivas, o comentário de cada alternativa diz quais itens são verdadeiros ou falsos e por quê.
- Textos e casos dos grupos: escreva como texto CORRIDO e narrado (uma história com personagens, órgão ou empresa, fatos encadeados e datas/números quando couber), nunca como lista de frases soltas uma por linha. Cada item do grupo explora um ponto diferente do mesmo caso.
- Itens que só copiam o texto da lei: no máximo 1 em cada 5 questões. Mesmo nas fáceis, prefira aplicar a regra a um caso curto.
- Varie o começo dos enunciados; não repita a mesma frase de abertura (ex.: "À luz do art. X, julgue o item") em todas as questões.
- Nível de cursinho de ponta:
  - Em Certo/Errado, quebre as "regrinhas de chute": inclua itens CERTOS com "sempre", "nunca", "somente" e itens ERRADOS com "pode", "em regra", "geralmente" — o aluno precisa saber o conteúdo, não adivinhar pela palavra.
  - Priorize o que mais cai: os pontos clássicos de prova do tópico e as novidades legislativas e jurisprudenciais dos últimos anos (conferidas na web).
  - Toda explicação aponta o fundamento: a regra ou o conceito exato que resolve a questão, e termina com uma frase prática de como reconhecer esse tipo de questão na prova.
  - Cada questão traz o campo "pegadinha": UMA frase dizendo qual é a armadilha da questão (o que faz o candidato errar).
- Cada questão leva "estilo" com o nome do estilo do lote (CEBRASPE, FGV, FCC, CESGRANRIO).

## Regras de qualidade
1. Regra precisa, com exemplos concretos; nunca invente regra ou dado.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Alternativas HOMOGÊNEAS: todas da mesma categoria da resposta (se a resposta é um tipo de oração coordenada, as cinco são tipos de coordenada; se é um prazo, as cinco são prazos plausíveis; se é um instituto, as cinco são institutos vizinhos). Proibido incluir alternativa de outra categoria que se elimina sem pensar. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Em Certo/Errado, as duas opções NÃO levam "comentario" (só a explanation). Em múltipla escolha: cada alternativa tem "comentario" próprio (1–2 frases: por que está certa ou, se errada, qual o erro específico) e a "explanation" geral (mínimo 80 caracteres) explica a regra/conceito **sem citar letras** (nada de "A", "B", "alternativa C"). Em Certo/Errado a explanation começa com "Certo." ou "Errado." e explica o item (mínimo 120 caracteres). Cada texto escrito de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo informatica.sistema-operacional-windows.banco-N.json, onde N é o lote)
```json
{
  "materia": "informatica.sistema-operacional-windows",
  "lote": 1,
  "estilo": "CEBRASPE",
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "estilo": "CEBRASPE", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false, "comentario": "erro específico desta alternativa" }, { "key": "B", "text": "...", "correct": true, "comentario": "por que está certa" } ],
      "explanation": "...", "pegadinha": "a armadilha em uma frase" }
  ]
}
```
- format: "MULTIPLE_CHOICE" (sempre 5 opções A–E) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
