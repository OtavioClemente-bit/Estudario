Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Língua Portuguesa: Formação de palavras** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 2 lotes de 50 questões, um por resposta. Quando eu pedir "lote 1", entregue o lote 1; quando eu pedir "lote 2", entregue o lote 2, sem repetir casos do lote 1.

## Escopo
Morfemas e estrutura lexical (radical, afixos, vogal temática, desinência e elementos de ligação); derivação e suas modalidades; composição por justaposição e aglutinação; hibridismo; onomatopeias; siglas, acrônimos, abreviaturas, redução vocabular e outros processos produtivos; elementos greco-latinos e critérios de reconhecimento.
Fica de fora (outras matérias tratam): Paradigmas completos de flexão nominal e verbal, análise sintática, modalização discursiva em profundidade e reconstrução histórica exaustiva de etimologias.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Estrutura e formação de palavras.
- Elementos estruturais e processos de formação de palavras.
- Formas de abreviação.
- Estrutura e formação de palavras e formas de abreviação.
- Morfologia e estrutura das palavras.
- Formação de palavras.
- Morfologia: estrutura e formação de palavras.
- Processos de formação de palavras.
- Processos de formação palavras.
- Processo de formação de palavras.
- Estrutura e formação de palavras, abreviações e classes de palavras.
- Estrutura e formação de palavras e abreviações.
- Morfologia: estrutura e formação de palavras e vozes verbais e sua conversão.
- Processos de formação das palavras.
- Estrutura e formação de palavras, abreviação e classes de palavras.
- Estrutura e formação de palavras; formas de abreviação.
- Formação de palavras, abreviação e classes de palavras.
- Estrutura e formação de palavras, classes de palavras e modalizadores.
- Estrutura, formação e abreviação de palavras.
- Morfologia: estrutura e formação das palavras; radicais gregos e latinos.
- Formação, estrutura e classes de palavras e modalizadores.
- Morfologia: estrutura e formação das palavras (radical, afixos, desinências, vogais e consoantes de ligação).
- Processos de formação de palavras: derivação, composição, hibridismo, onomatopeia, siglas e abreviações.
- Morfologia: formação e classe de palavras.
- Estrutura do vocábulo: flexão dos vocábulos, seu valor e significação dentro de frases.
- Descrição linguística: unidades linguísticas: orações, sintagmas, palavras, morfemas.
- Estrutura de palavras.
- Formação de palavras, abreviações e classes gramaticais.
- Textos da esfera científica/acadêmica — Análise linguística: Identifique os processos corriqueiros de formação de palavras (afixos, derivações e composições) essenciais ao léxico técnico.
- Processos de formação de palavras e emprego das classes de palavras.

## Cada lote de 50
- 25 de múltipla escolha A a E (5 alternativas), 13 de múltipla escolha A a D (4 alternativas), 12 de Certo/Errado.
- Dificuldade: 15 fáceis, 20 médias, 15 difíceis. Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, comparação entre conceitos parecidos. Use casos DIFERENTES entre si; nada de repetir o mesmo caso com outras palavras.

## Regras de qualidade
1. Regra precisa, com exemplos concretos; nunca invente regra ou dado.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Explicação (mínimo 120 caracteres): por que a certa está certa e por que CADA errada erra, com o conceito específico. Em Certo/Errado começa com "Certo." ou "Errado.". Escreva cada explicação de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo portugues.formacao-de-palavras.banco-N.json, onde N é o lote)
```json
{
  "materia": "portugues.formacao-de-palavras",
  "lote": 1,
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false }, { "key": "B", "text": "...", "correct": true } ],
      "explanation": "..." }
  ]
}
```
- format: "MULTIPLE_CHOICE" (A–E com 5 opções ou A–D com 4 opções) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
