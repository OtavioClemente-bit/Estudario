Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Direito Constitucional: Processo legislativo** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 4 lotes, um por resposta. Quando eu pedir 'lote N', entregue só aquele lote, sem repetir casos dos lotes anteriores:
- **Lote 1 (CEBRASPE, 50 questões):** 50 itens de Certo/Errado no estilo Cebraspe: afirmação curta e técnica, com o detalhe trocado (prazo, competência, exceção, conceito vizinho); explanation começa com Certo. ou Errado. Como na prova, cerca de 20 dos 50 itens vêm em 4 grupos de 5 itens sobre um mesmo texto ou situação hipotética mais longa (8 a 15 linhas); repita esse texto completo no statement de cada item do grupo, para cada item funcionar sozinho.
- **Lote 2 (FGV, 40 questões):** 40 de múltipla escolha A a E no estilo FGV: caso concreto mais longo, aplicação e interpretação; as erradas são aplicações plausíveis mas equivocadas.
- **Lote 3 (FCC, 40 questões):** 40 de múltipla escolha A a E no estilo FCC: mais literal, cobra o texto da norma/regra com o detalhe de prazo, número, competência ou exceção.
- **Lote 4 (CESGRANRIO, 40 questões):** 40 de múltipla escolha A a E no estilo Cesgranrio, FUMARC, IDECAN, IBFC e bancas de nível médio: enunciado curto e direto, uma regra por questão.

## Escopo
Espécies normativas do art. 59; emendas constitucionais e limites; iniciativa e emendas; tramitação, deliberação, sanção, veto, promulgação e publicação; medidas provisórias; leis delegadas; leis complementares e ordinárias; decretos legislativos, resoluções e técnica legislativa básica.
Fica de fora (outras matérias tratam): Organização e estatuto dos congressistas; competências institucionais detalhadas; controle financeiro e orçamentário aprofundado; processos estaduais e municipais além de referência indispensável.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Processo legislativo.
- Do Processo Legislativo.
- Poder legislativo: Processo legislativo.
- Do Poder Legislativo: do processo legislativo.
- Procedimento Legislativo: definição; tipos: normal ou ordinário, abreviado, sumário, sumaríssimo, especial, concentrado.
- Processo Legislativo: definição, natureza jurídica, princípios gerais.
- Noções básicas: anteprojeto, autógrafos, unicameralismo e bicameralismo, blocos parlamentares, comissões, correção de erro, deliberação, destaque, emendas, iniciativa, legislatura.
- Noções básicas: sanção, sessões legislativas, turnos, urgência, veto, votação, voto vencido em separado.
- Iniciativa do processo de elaboração das leis: concorrente, reservada ou exclusiva, vinculada, popular.
- Tramitação de proposições: projeto de lei ordinária; projeto de lei complementar; projeto de decreto legislativo, projeto de resolução, indicação, parecer, emenda, requerimentos.
- Processo legislativo federal: conceito, espécies normativas, modalidades, fases.
- Processo legislativo estadual, distrital e municipal: normas constitucionais federais aplicáveis.
- Poder Legislativo: Do Processo Legislativo.
- Espécies normativas.
- Processo legislativo estadual.
- Poder Legislativo, processo legislativo e fiscalização.
- Do Processo Legislativo, da fiscalização contábil, financeira e orçamentária.
- Processo Legislativo: fundamentos e garantias de independência, conceito, objetos, atos e procedimentos.
- Processo legislativo: fundamento e garantias de independência, conceito, objetos, atos e procedimentos.
- Processo legislativo: conceito, objeto, espécies de atos normativos e procedimentos.
- Iniciativa.
- Emendas.
- Votação, sanção, veto, promulgação e publicação da lei.
- Medida Provisória.
- Direito Constitucional Aplicado ao Processo Legislativo.
- Processo legislativo constitucional: iniciativa, discussão, votação, sanção, veto, promulgação e publicação.
- Processo Legislativo Estadual e Organização do Poder Legislativo.
- Iniciativa legislativa: iniciativa parlamentar, iniciativa do Governador do Estado, iniciativa do Poder Judiciário, iniciativa do Ministério Público, iniciativa da Defensoria Pública, iniciativa popular, iniciativa privativa, iniciativa compartilhada.
- Limites constitucionais à iniciativa legislativa estadual.
- Tramitação de proposições legislativas.

## Em todos os lotes
- Dificuldade: 25% fáceis, 35% médias, 40% difíceis ("difficulty": FACIL, MEDIA, DIFICIL), seguindo estas definições:
  - **FACIL:** cobra a regra principal como está na lei ou no conceito; acerta quem leu a matéria uma vez.
  - **MEDIA:** aplica a regra a um caso concreto ou cobra um detalhe (prazo, competência, exceção); exige estudo atento.
  - **DIFICIL:** combina duas ou mais regras, cobra a exceção da exceção, jurisprudência que contraria a leitura literal, ou monta caso em que a resposta intuitiva está errada; erra quem estudou só o básico. Distratores das difíceis são quase certos (diferem num detalhe decisivo). Técnicas para o difícil: trocar UMA palavra decisiva ("pode"/"deve", "apenas"/"também", "e"/"ou", prazo, competência); afirmação quase toda correta com um único desvio no fim; inferência que parece óbvia mas o texto/norma não autoriza; generalização de uma exceção; inversão de causa e consequência; regra certa aplicada à hipótese errada.
  - Teste antes de marcar DIFICIL: se um candidato que estudou só o básico acertaria em poucos segundos, a questão é FACIL ou MEDIA — reclassifique ou torne-a mais exigente (ex.: em gramática, opor categorias vizinhas que se confundem de verdade, como coordenada explicativa x subordinada causal, "que" conjunção x pronome relativo, "onde" x "aonde"; em direito, regra x exceção x exceção da exceção).
  - A dificuldade vem do raciocínio exigido, NUNCA do tamanho do texto: questão difícil pode ser curta, e enunciado longo não torna a questão difícil.
- Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, literalidade da lei com o detalhe que a prova troca, jurisprudência e súmulas, comparação entre conceitos parecidos. Casos DIFERENTES entre si e entre lotes; nada de repetir o mesmo caso com outras palavras.
- Nos lotes de múltipla escolha (FGV, FCC, CESGRANRIO), varie o comando como nas provas: cerca de 65% "assinale a correta"; cerca de 20% "assinale a INCORRETA" (o comando deixa isso explícito em maiúsculas e só uma alternativa é falsa); cerca de 15% de assertivas — o enunciado traz itens I, II, III e IV (às vezes V) e as alternativas são combinações ("Apenas I e II.", "Apenas II, III e IV." etc.), com uma única combinação certa; nas assertivas, o comentário de cada alternativa diz quais itens são verdadeiros ou falsos e por quê.
- Textos e casos dos grupos: escreva como texto CORRIDO e narrado (uma história com personagens, órgão ou empresa, fatos encadeados e datas/números quando couber), nunca como lista de frases soltas uma por linha. Cada item do grupo explora um ponto diferente do mesmo caso.
- Itens que só copiam o texto da lei: no máximo 1 em cada 5 questões. Mesmo nas fáceis, prefira aplicar a regra a um caso curto.
- Varie o começo dos enunciados; não repita a mesma frase de abertura (ex.: "À luz do art. X, julgue o item") em todas as questões.
- Cerca de 1 em cada 5 questões cobra jurisprudência consolidada (súmula, súmula vinculante, tese de repercussão geral ou recurso repetitivo) relacionada ao tópico, sempre conferida em fonte oficial; se não tiver certeza do número, descreva o entendimento sem o número.
- Nível de cursinho de ponta:
  - Em Certo/Errado, quebre as "regrinhas de chute": inclua itens CERTOS com "sempre", "nunca", "somente" e itens ERRADOS com "pode", "em regra", "geralmente" — o aluno precisa saber o conteúdo, não adivinhar pela palavra.
  - Priorize o que mais cai: os pontos clássicos de prova do tópico e as novidades legislativas e jurisprudenciais dos últimos anos (conferidas na web).
  - Toda explicação aponta o fundamento: o dispositivo (artigo, inciso, súmula ou tese) que resolve a questão, e termina com uma frase prática de como reconhecer esse tipo de questão na prova.
  - Cada questão traz o campo "pegadinha": UMA frase dizendo qual é a armadilha da questão (o que faz o candidato errar).
- Cada questão leva "estilo" com o nome do estilo do lote (CEBRASPE, FGV, FCC, CESGRANRIO).

## Regras de qualidade
1. Cite artigo, lei, súmula e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Se não tiver certeza de um número, explique sem ele — nunca invente.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Alternativas HOMOGÊNEAS: todas da mesma categoria da resposta (se a resposta é um tipo de oração coordenada, as cinco são tipos de coordenada; se é um prazo, as cinco são prazos plausíveis; se é um instituto, as cinco são institutos vizinhos). Proibido incluir alternativa de outra categoria que se elimina sem pensar. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Em Certo/Errado, as duas opções NÃO levam "comentario" (só a explanation). Em múltipla escolha: cada alternativa tem "comentario" próprio (1–2 frases: por que está certa ou, se errada, qual o erro específico) e a "explanation" geral (mínimo 80 caracteres) explica a regra/conceito **sem citar letras** (nada de "A", "B", "alternativa C"). Em Certo/Errado a explanation começa com "Certo." ou "Errado." e explica o item (mínimo 120 caracteres). Cada texto escrito de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo direito-constitucional.processo-legislativo.banco-N.json, onde N é o lote)
```json
{
  "materia": "direito-constitucional.processo-legislativo",
  "lote": 1,
  "estilo": "CEBRASPE",
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "estilo": "CEBRASPE", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false, "comentario": "erro específico desta alternativa" }, { "key": "B", "text": "...", "correct": true, "comentario": "por que está certa" } ],
      "explanation": "...", "pegadinha": "a armadilha em uma frase" }
  ]
}
```
- format: "MULTIPLE_CHOICE" (sempre 5 opções A–E) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
