Você é autor de questões de concurso público no Brasil. Crie um BANCO DE QUESTÕES de **Direito Administrativo: Poderes administrativos e abuso de poder** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco. Pesquise na web e use fontes oficiais.

São 5 lotes, um por resposta. Quando eu pedir 'lote N', entregue só aquele lote, sem repetir casos dos lotes anteriores:
- **Lote 1 (CEBRASPE, 50 questões):** 50 itens de Certo/Errado no estilo Cebraspe: afirmação curta e técnica, com o detalhe trocado (prazo, competência, exceção, conceito vizinho); explanation começa com Certo. ou Errado.
- **Lote 2 (CEBRASPE, 50 questões):** mais 50 itens de Certo/Errado no estilo Cebraspe, cobrindo outros pontos e casos que o lote 1.
- **Lote 3 (FGV, 30 questões):** 30 de múltipla escolha A a E no estilo FGV: caso concreto mais longo, aplicação e interpretação; as erradas são aplicações plausíveis mas equivocadas.
- **Lote 4 (FCC, 30 questões):** 30 de múltipla escolha A a E no estilo FCC: mais literal, cobra o texto da norma/regra com o detalhe de prazo, número, competência ou exceção.
- **Lote 5 (VUNESP, 30 questões):** 30 de múltipla escolha A a E no estilo Vunesp e bancas de nível médio: enunciado curto e direto, uma regra por questão.

## Escopo
Poderes vinculado, discricionário, hierárquico, disciplinar, regulamentar e de polícia; ciclo, atributos e delegação de polícia; deveres administrativos; abuso por excesso e desvio; limites, prazos e enriquecimento ilícito relacionado.
Fica de fora (outras matérias tratam): Teoria geral dos atos administrativos, ritos disciplinares específicos, licitações, responsabilidade civil e crimes funcionais, salvo conexões indispensáveis ao exame dos poderes.

## Tópicos dos editais (distribua as questões entre eles; pelo menos 2 por tópico, mais nos primeiros, que são os mais cobrados; se algum item for claramente de outra matéria, ignore-o)
- Poderes administrativos.
- Uso e abuso do poder.
- Poderes administrativos: Hierárquico, disciplinar, regulamentar e de polícia.
- Poderes administrativos: Uso e abuso do poder.
- Poderes da Administração Pública.
- Poderes administrativos: poder hierárquico, poder disciplinar, poder regulamentar, poder de polícia, uso e abuso do poder.
- Poder de polícia.
- Poderes da administração pública: Hierárquico, disciplinar, regulamentar e de polícia.
- Poderes da administração: vinculado, discricionário, hierárquico, disciplinar e regulamentar.
- Enriquecimento ilícito e uso e abuso de poder.
- Poder disciplinar.
- Poderes administrativos e uso e abuso do poder.
- Poderes e deveres dos administradores públicos.
- Poderes hierárquico, disciplinar, regulamentar e de polícia.
- Liberdades públicas e poder de polícia.
- Principais setores de atuação da polícia administrativa.
- Poderes e deveres da administração pública.
- Polícia judiciária e polícia administrativa.
- Poder Regulamentar.
- Poderes e deveres da administração pública: Poder regulamentar.
- Hierarquia: poder hierárquico e suas manifestações.
- Poderes hierárquico, disciplinar, regulamentar e de polícia; uso e abuso do poder.
- Poderes da administração pública: poder disciplinar.
- Poderes da administração pública: poder de polícia.
- Poderes da administração pública: liberdades públicas e poder de polícia.
- Poderes e deveres da administração pública: Dever de agir.
- Poderes administrativos: hierárquico, disciplinar, regulamentar e de polícia; uso e abuso do poder.
- Poderes da administração pública: Uso e abuso de poder.
- Poderes da Administração Pública: poder hierárquico, poder disciplinar, poder regulamentar, poder de polícia.
- Poderes administrativos hierárquico, disciplinar, regulamentar e de polícia; uso e abuso do poder.

## Em todos os lotes
- Dificuldade: 25% fáceis, 35% médias, 40% difíceis ("difficulty": FACIL, MEDIA, DIFICIL), seguindo estas definições:
  - **FACIL:** cobra a regra principal como está na lei ou no conceito; acerta quem leu a matéria uma vez.
  - **MEDIA:** aplica a regra a um caso concreto ou cobra um detalhe (prazo, competência, exceção); exige estudo atento.
  - **DIFICIL:** combina duas ou mais regras, cobra a exceção da exceção, jurisprudência que contraria a leitura literal, ou monta caso em que a resposta intuitiva está errada; erra quem estudou só o básico. Distratores das difíceis são quase certos (diferem num detalhe decisivo).
  - A dificuldade vem do raciocínio exigido, NUNCA do tamanho do texto: questão difícil pode ser curta, e enunciado longo não torna a questão difícil.
- Gabarito espalhado entre as letras; Certo/Errado com metade de cada.
- Varie o tipo: caso concreto, literalidade da lei com o detalhe que a prova troca, jurisprudência e súmulas, comparação entre conceitos parecidos. Casos DIFERENTES entre si e entre lotes; nada de repetir o mesmo caso com outras palavras.
- Cada questão leva "estilo" com o nome do estilo do lote (CEBRASPE, FGV, FCC, VUNESP).

## Regras de qualidade
1. Cite artigo, lei, súmula e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Se não tiver certeza de um número, explique sem ele — nunca invente.
2. **Todo número, nome ou dado usado nas alternativas e na explicação precisa estar no enunciado** (ou ser resultado de conta com os dados do enunciado).
3. Distratores = erro de quem estudou MAL (conceito vizinho, número ou prazo trocado, exceção esquecida, conta com base errada). Proibido distrator absurdo, de outro assunto, "todas/nenhuma das anteriores" ou absolutos só para marcar o errado.
4. Alternativas com tamanho parecido; a certa não pode ser a mais longa em mais de 1/3 das questões.
5. Em múltipla escolha: cada alternativa tem "comentario" próprio (1–2 frases: por que está certa ou, se errada, qual o erro específico) e a "explanation" geral (mínimo 80 caracteres) explica a regra/conceito **sem citar letras** (nada de "A", "B", "alternativa C"). Em Certo/Errado a explanation começa com "Certo." ou "Errado." e explica o item (mínimo 120 caracteres). Cada texto escrito de forma própria: proibido frase-molde repetida entre questões.
6. Texto neutro: não escreva nome de banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
7. Antes de entregar, resolva cada questão como candidato: uma única alternativa defensável e gabarito certo.

## Formato de entrega (um bloco JSON válido; se puder, como arquivo direito-administrativo.poderes-administrativos.banco-N.json, onde N é o lote)
```json
{
  "materia": "direito-administrativo.poderes-administrativos",
  "lote": 1,
  "estilo": "CEBRASPE",
  "questions": [
    { "topico": "<texto exato de um tópico da lista>", "estilo": "CEBRASPE", "statement": "...", "format": "MULTIPLE_CHOICE", "difficulty": "FACIL",
      "options": [ { "key": "A", "text": "...", "correct": false, "comentario": "erro específico desta alternativa" }, { "key": "B", "text": "...", "correct": true, "comentario": "por que está certa" } ],
      "explanation": "..." }
  ]
}
```
- format: "MULTIPLE_CHOICE" (sempre 5 opções A–E) ou "TRUE_FALSE" (opções { "key":"C","text":"Certo" } e { "key":"E","text":"Errado" }). difficulty: "FACIL", "MEDIA" ou "DIFICIL".
