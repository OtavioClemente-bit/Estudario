Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Direito Constitucional: Fiscalização contábil, financeira e orçamentária (arts. 70 a 75)** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Arts. 70 a 75 da Constituição Federal: cinco dimensões de fiscalização, parâmetros e dever de prestar contas, controle externo federal, competências e composição do TCU, controle interno, prestação de contas, decisões, atos normativos, simetria estadual e distrital, controle municipal, EC 139/2026 e precedentes pertinentes.

Fica de fora (outras matérias tratam): Processo orçamentário em geral, controle judicial como matéria autônoma, improbidade administrativa e regime de responsabilidade fiscal; referências pontuais apenas para delimitar competências e efeitos das decisões.

Os editais pedem este assunto assim (cubra todos estes pontos):
- Fiscalização contábil, financeira e orçamentária.
- Poder Legislativo: fiscalização contábil, financeira e orçamentária.
- Controle da atividade financeira do Estado: espécies e sistemas.
- Fiscalização financeira e orçamentária.
- Tribunal de Contas da União e suas atribuições.
- Tribunal de Contas da União.
- Tribunal de Contas da União (TCU).
- Da fiscalização contábil, financeira e orçamentária.
- Fiscalização e controle interno e externo dos orçamentos.
- Poder legislativo: Tribunal de Contas da União (TCU).
- Tribunal de Contas da União (TCU) e suas atribuições; entendimentos com caráter normativo exarados pelo TCU.
- Fiscalização contábil, financeira, orçamentária, operacional e patrimonial.
- Fiscalização contábil, financeira e orçamentária e comissões parlamentares de inquérito.
- Fiscalização contábil, financeira e orçamentária operacional e patrimonial.
- Tribunais de Contas na Constituição Federal: regime jurídico, estrutura, composição, competência, natureza jurídica e eficácia das decisões.
- Poder Legislativo e os tribunais de contas.
- Controle interno e os tribunais de contas.
- Fiscalização contábil, financeira e orçamentária, controle externo e sistema de controle interno.
- Poder Legislativo: Da Fiscalização Contábil, Financeira e Orçamentária.
- O controle externo e os sistemas de controle interno.
- Controle, fiscalização e prestação de contas.
- Regras constitucionais sobre controle externo: fiscalização contábil, financeira, orçamentária, operacional e patrimonial.
- Poder Legislativo: fiscalização contábil e financeira.
- Tribunal de Contas da União (TCU) e suas atribuições.
- Jurisprudência do STF sobre o controle externo.

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "direito-constitucional.fiscalizacao-contabil-financeira",
  "subject": "Direito Constitucional",
  "title": "Fiscalização contábil, financeira e orçamentária (arts. 70 a 75)",
  "version": 4,
  "status": "PUBLISHED",
  "aliases": ["Fiscalização contábil, financeira e orçamentária (arts. 70 a 75)"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome direito-constitucional.fiscalizacao-contabil-financeira.json.
