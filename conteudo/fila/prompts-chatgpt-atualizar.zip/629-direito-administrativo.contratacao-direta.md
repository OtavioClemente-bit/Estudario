Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Direito Administrativo: Contratação direta: dispensa e inexigibilidade** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Dever de licitar; inexigibilidade do art. 74; dispensa do art. 75 e limites monetários atualizados; licitação dispensada nas hipóteses de alienação do art. 76; instrução e publicidade do processo de contratação direta do art. 72.

Fica de fora (outras matérias tratam): Modalidades e princípios licitatórios, fases, recursos, execução contratual, sanções e crimes, tratados em tópicos próprios.

Os editais pedem este assunto assim (cubra todos os pontos que pertencem ao escopo acima). **Atenção:** se algum item da lista for claramente de outra matéria (fora do escopo — ex.: regime de servidores numa matéria de controle judicial), IGNORE esse item; nunca crie capítulo ou questões para assunto fora do escopo.
- Contratação direta: dispensa e inexigibilidade.
- Licitação: Contratação direta: dispensa e inexigibilidade.
- Obrigatoriedade, dispensa e inexigibilidade.
- Obrigatoriedade, dispensa, inexigibilidade e vedação.
- Licitação: dispensa e inexigibilidade.
- Licitação: obrigatoriedade, dispensa, inexigibilidade e vedação.
- Dispensa e inexigibilidade.
- Dispensa e inexigibilidade de licitação.
- Licitação: Contratação direta.
- Licitação e contratos administrativos: Contratação direta: dispensa e inexigibilidade.
- Disposições doutrinárias: Contratação direta.
- Fracionamento de despesas.
- Princípios, dispensa e inexigibilidade.
- Lei nº 14.133/2021: contratação direta, dispensa e inexigibilidade.
- Licitações, contratação direta, dispensa, inexigibilidade e contratos administrativos.
- Contratação direta: dispensa e inexigibilidade; conceito.
- Dispensa de licitação.
- Inexigibilidade de licitação.
- Disposições doutrinárias: Contratação direta: dispensa e inexigibilidade.
- Licitações: obrigatoriedade, dispensa, inexigibilidade e vedação.
- Licitação de obras públicas: Hipóteses de dispensa, de inexigibilidade e de vedação.
- Obrigatoriedade da licitação e contratação direta.
- Dispensa e inexigibilidade de licitação: hipóteses legais e requisitos de instrução processual.
- Hipóteses de dispensa, de inexigibilidade e de vedação.
- Dispensa e inexigibilidade. Anulação e revogação. Controle. Aspectos penais.

## O que a versão atual não cobre (revisão contra os editais — inclua, se for do escopo)
- seção sobre as vedações ligadas à contratação direta (fracionamento de despesa para fugir da licitação, impedimentos de contratar, vedação a agentes com conflito de interesse) e 5 questões
- seção sobre as vedações ligadas à contratação direta (fracionamento de despesa, impedimentos de contratar, conflito de interesse) e 5 questões
- seção sobre vedações e hipóteses de dispensa e inexigibilidade específicas de obras e serviços de engenharia (limites para obras, fracionamento) e 6 questões
- seção sobre vedações e hipóteses de dispensa e inexigibilidade específicas de obras e serviços de engenharia (limites, fracionamento, emergência) e 6 questões
- capítulo sobre procedimentos auxiliares (credenciamento, pré-qualificação, procedimento de manifestação de interesse, sistema de registro de preços, registro cadastral) e 8 questões

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "direito-administrativo.contratacao-direta",
  "subject": "Direito Administrativo",
  "title": "Contratação direta: dispensa e inexigibilidade",
  "version": 3,
  "status": "PUBLISHED",
  "aliases": ["Contratação direta: dispensa e inexigibilidade"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome direito-administrativo.contratacao-direta.json.
