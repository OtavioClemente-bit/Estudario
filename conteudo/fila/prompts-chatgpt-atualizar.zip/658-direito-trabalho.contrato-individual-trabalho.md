Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Direito do Trabalho: Contrato individual de trabalho** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Conceito, elementos, classificação e duração do contrato individual; trabalho intermitente; alteração contratual, jus variandi, suspensão e interrupção; jornada e condições especiais do trabalho; insalubridade e periculosidade; negociação coletiva; término, justas causas, despedida indireta, dispensa arbitrária, despedida coletiva, culpa recíproca, indenizações e aviso-prévio; dano extrapatrimonial, acidentes de trabalho e atos normativos do TST pertinentes.

Fica de fora (outras matérias tratam): Estabilidades e garantias provisórias, férias, salário e remuneração, descanso semanal, trabalho noturno e horas extras como temas autônomos; processo do trabalho; regime jurídico estatutário; segurança social e benefícios previdenciários além de seus reflexos básicos no contrato.

Os editais pedem este assunto assim (cubra todos os pontos que pertencem ao escopo acima). **Atenção:** se algum item da lista for claramente de outra matéria (fora do escopo — ex.: regime de servidores numa matéria de controle judicial), IGNORE esse item; nunca crie capítulo ou questões para assunto fora do escopo.
- Contrato individual de trabalho: conceito, classificação e características.
- Do contrato individual de trabalho: conceito, classificação e características.
- Instruções e atos Normativos do TST em matéria de Direito do Trabalho.
- Dos poderes do empregador no contrato de trabalho.
- Contrato individual de trabalho.
- Contrato individual de trabalho: conceito, classificação, características e alterações unilaterais e bilaterais.
- Sujeitos do contrato de trabalho stricto sensu: Poderes do empregador no contrato de trabalho.
- Contrato individual de trabalho: conceito, classificação, modalidades, características, profissões regulamentadas e alteração unilateral e bilateral.
- Contrato individual de trabalho: conceito, requisitos, classificação.
- Contrato de trabalho, modalidades, alterações, suspensão, interrupção e extinção.
- Contrato individual de trabalho: conceito, requisitos e classificação.
- Renúncia, transação, invalidade, efeitos e poderes do empregador no contrato de emprego.
- Poderes do empregador no contrato de trabalho.
- Contratos de Trabalho e Contratos afins.
- Contrato individual de trabalho: alteração, suspensão, rescisão e estabilidade.
- Contrato de trabalho, remuneração, duração do trabalho, férias, suspensão, interrupção e rescisão.
- Legislação que regula os contratos empregatícios nos cartórios – CLT.
- Contrato individual de trabalho, modalidades, profissões regulamentadas, alterações, transferência, suspensão, interrupção e rescisão; aviso prévio, estabilidade e garantias provisórias.
- Alteração, suspensão e interrupção do contrato de trabalho.
- Contrato individual de trabalho: Conceito, classificação, modalidades e características.
- Contrato individual de trabalho: Profissões Regulamentadas.
- Contrato individual de trabalho e convenções coletivas.
- Contrato individual, salários especiais, organização sindical, convenções e acordos coletivos, mediação e arbitragem.
- Do contrato individual do trabalho.

## O que a versão atual não cobre (revisão contra os editais — inclua, se for do escopo)
- seção sobre renúncia, transação, invalidade dos atos e efeitos do contrato (nulidades, princípio da irrenunciabilidade), com 6 questões
- seção sobre contratos afins (empreitada, representação comercial, estágio, trabalho autônomo, cooperativa, terceirização) e 6 questões
- capítulo sobre estabilidades e garantias provisórias de emprego (dirigente sindical, cipeiro, gestante, acidentado) e 8 questões
- capítulos sobre remuneração, férias e duração do trabalho com questões
- seção sobre o contrato de trabalho dos empregados de serventias extrajudiciais (regime celetista, Lei dos Cartórios) e 5 questões
- capítulo sobre estabilidade e garantias provisórias, profissões regulamentadas e transferência, com 10 questões
- seção sobre profissões regulamentadas (jornalista, médico, advogado, bancário, professor, etc.) e 6 questões
- capítulos sobre salários especiais, organização sindical, convenções e acordos coletivos e mediação e arbitragem, com 10 questões

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "direito-trabalho.contrato-individual-trabalho",
  "subject": "Direito do Trabalho",
  "title": "Contrato individual de trabalho",
  "version": 6,
  "status": "PUBLISHED",
  "aliases": ["Contrato individual de trabalho"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome direito-trabalho.contrato-individual-trabalho.json.
