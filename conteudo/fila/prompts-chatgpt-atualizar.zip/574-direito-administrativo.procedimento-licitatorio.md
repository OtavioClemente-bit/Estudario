Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Direito Administrativo: Procedimento licitatório, anulação, revogação e recursos** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Fases e inversão de fases do art. 17; anulação e revogação pelo art. 71; recursos e pedidos de reconsideração dos arts. 165 a 168 da Lei 14.133/2021.

Fica de fora (outras matérias tratam): Contratação direta, modalidades em profundidade, critérios de julgamento e habilitação além do necessário para compreender as fases, execução e sanções contratuais.

Os editais pedem este assunto assim (cubra todos os pontos que pertencem ao escopo acima). **Atenção:** se algum item da lista for claramente de outra matéria (fora do escopo — ex.: regime de servidores numa matéria de controle judicial), IGNORE esse item; nunca crie capítulo ou questões para assunto fora do escopo.
- Licitação: Procedimento.
- Procedimento licitatório.
- Anulação, revogação e recursos administrativos.
- Procedimento, revogação e anulação.
- Licitação: procedimento, revogação e anulação.
- Procedimento.
- Noções de Licitações e Contratos (Lei nº 14.133/2021 e suas alterações): Estudo Técnico Preliminar.
- Noções de Licitações e Contratos (Lei nº 14.133/2021 e suas alterações): Termo de Referência.
- Anulação e revogação.
- Disposições doutrinárias: Procedimento.
- Disposições doutrinárias: Anulação e revogação.
- Licitação e contratos administrativos: Procedimento.
- Licitação: anulação, revogação e recursos administrativos.
- Revogação e anulação da licitação.
- Habilitação.
- Julgamento.
- Licitações: Anulação e revogação.
- Revogação e anulação, hipóteses e efeitos.
- Fases do procedimento licitatório.
- Anulação e revogação da licitação.
- Adjudicação, homologação e formalização contratual.
- Anulação, revogação, recursos, sanções e crimes em licitações e contratos.
- Lei nº 14.133/2021: procedimento.
- Procedimento, revogação e anulação da licitação.
- Noções de Licitações e Contratos (Lei nº 14.133/2021): Estudo Técnico Preliminar.

## O que a versão atual não cobre (revisão contra os editais — inclua, se for do escopo)
- capítulo sobre a fase preparatória: estudo técnico preliminar (conteúdo, dispensa, finalidade) e 6 questões
- seção sobre termo de referência (conteúdo, elementos do art. 6º, relação com o ETP) e 6 questões
- seção sobre habilitação (arts. 62 a 70: jurídica, fiscal, social e trabalhista, técnica, econômico-financeira) e 8 questões
- capítulo sobre estudo técnico preliminar (elementos do art. 18 §1º, dispensa, finalidade) e 6 questões
- seção sobre o panorama de sanções (art. 156) e crimes em licitações (Código Penal, arts. 337-E a 337-P) com 6 questões
- seção sobre projeto básico e projeto executivo (conteúdo, anteprojeto, obras e serviços de engenharia) e 6 questões
- seção sobre habilitação e impedimentos (art. 14: vedações de participação; arts. 62 a 70: requisitos de habilitação) e 8 questões
- seção sobre aplicação do procedimento a obras e serviços de engenharia (projeto básico, regimes de execução, orçamento, BDI) e 6 questões
- seção sobre os artefatos de planejamento (ETP, termo de referência, projeto básico) e sua sequência na fase preparatória, com 8 questões
- seção sobre julgamento objetivo das propostas, desclassificação e critérios de desempate (art. 60) com 6 questões

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "direito-administrativo.procedimento-licitatorio",
  "subject": "Direito Administrativo",
  "title": "Procedimento licitatório, anulação, revogação e recursos",
  "version": 3,
  "status": "PUBLISHED",
  "aliases": ["Procedimento licitatório, anulação, revogação e recursos"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome direito-administrativo.procedimento-licitatorio.json.
