Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Direito Constitucional: Ministério Público e MPT** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Arts. 127 a 130-A da Constituição: perfil e princípios do Ministério Público, autonomia, ramos do MPU e MPT, chefia, ingresso, garantias, vedações, funções, CNMP e atuação constitucional trabalhista (art. 114, § 3º), com LC nº 75/1993 como apoio.

Fica de fora (outras matérias tratam): Organização infraconstitucional detalhada das carreiras; ritos processuais; atribuições de ramos e órgãos que ultrapassem a compreensão constitucional do MP/MPT; estudo aprofundado de Advocacia Pública, advocacia e Defensoria Pública, citadas apenas em contraste.

Os editais pedem este assunto assim (cubra todos os pontos que pertencem ao escopo acima). **Atenção:** se algum item da lista for claramente de outra matéria (fora do escopo — ex.: regime de servidores numa matéria de controle judicial), IGNORE esse item; nunca crie capítulo ou questões para assunto fora do escopo.
- Ministério Público.
- Funções essenciais à Justiça: Ministério Público.
- Funções essenciais à justiça: Ministério Público, Advocacia Pública.
- Funções essenciais à justiça: Ministério Público e Advocacia Pública.
- Ministério Público: princípios, garantias, vedações, organização e competências.
- Funções essenciais à justiça: Ministério Público, Advocacia Pública e Defensoria Pública.
- Funções essenciais à justiça: Ministério Público, Advocacia e Defensoria Públicas.
- Conselho Nacional do Ministério Público.
- Das funções essenciais à Justiça: do Ministério Público.
- Funções essenciais à Justiça: Ministério Público, advocacia e Defensoria Pública.
- Conselho Nacional do Ministério Público: composição e atribuições constitucionais.
- Ministério Público, Advocacia Pública.
- Membros do MPU: ingresso, promoção, aposentadoria, garantias, prerrogativas e vedações.
- Ministério Público, Ministério Público junto aos tribunais de contas e advocacia pública.
- Constituição da República Federativa do Brasil de 1988: Funções essenciais à justiça.
- Funções essenciais à Justiça: Ministério Público, Advocacia Pública, advocacia e Defensoria Pública.
- Constituição Federal: Título IV, Capítulo IV, Seção I.
- Ramos do Ministério Público e funções exclusivas e concorrentes.
- Lei Complementar nº 75/1993.
- Funções essenciais à Justiça, Ministério Público, Advocacia Pública, advocacia e Defensoria Pública.
- Funções essenciais à justiça. Ministério Público e Advocacia Pública.
- Ministério Público: Conselho Nacional do Ministério Público.
- Funções essenciais à Justiça: Ministério Público, princípios, garantias, vedações, organização e competências.
- Funções essenciais à Justiça: do Ministério Público.
- Funções essenciais à Justiça: Ministério Público: princípios, garantias, vedações, organização e competências.

## O que a versão atual não cobre (revisão contra os editais — inclua, se for do escopo)
- seção de contraste com a Advocacia Pública (arts. 131 e 132: AGU, Procuradorias, representação judicial e consultoria) e 5 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- seção sobre Advocacia Pública e Defensoria Pública (arts. 131 a 135) e 8 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- seção sobre Advocacia Pública, advocacia e Defensoria Pública (arts. 131 a 135) e 8 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- capítulo sobre a organização do MPU na LC 75/1993 (ramos, chefias, órgãos colegiados, carreira e regime disciplinar) e 8 questões
- seção sobre Advocacia Pública (arts. 131 e 132) e 5 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- seção sobre iniciativa legislativa do MPU (leis de criação de cargos, remuneração e organização) e 4 questões
- seção sobre as demais funções essenciais à Justiça (Advocacia Pública, advocacia e Defensoria Pública), que o tópico menciona junto ao MP, e 6 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- seção sobre Advocacia Pública (arts. 131 e 132), que o tópico exige junto ao MP, e 5 questões (ou ligar também a direito-constitucional.advocacia-defensoria)
- capítulo sobre a Lei Orgânica Nacional do Ministério Público dos Estados (Lei 8.625/1993): órgãos, Procurador-Geral de Justiça, Conselho Superior, garantias e carreira, com 8 questões
- seção sobre iniciativa legislativa do MP (propor ao Legislativo a criação e extinção de cargos e serviços auxiliares, remuneração) e 4 questões

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "direito-constitucional.ministerio-publico",
  "subject": "Direito Constitucional",
  "title": "Ministério Público e MPT",
  "version": 5,
  "status": "PUBLISHED",
  "aliases": ["Ministério Público e MPT"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome direito-constitucional.ministerio-publico.json.
