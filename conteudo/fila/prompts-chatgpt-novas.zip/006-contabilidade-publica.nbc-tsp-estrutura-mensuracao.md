Você é professor de cursinho preparatório e autor de questões de concurso público no Brasil. Escreva uma matéria completa de **Contabilidade Pública: NBC TSP: estrutura conceitual, reconhecimento e mensuração** para o aplicativo Estudário, no nível das provas de tribunais, polícias, agências e fisco (Cebraspe, FGV, FCC, Vunesp, IBFC). Pesquise na web e use fontes oficiais.

## Escopo
Estrutura conceitual da NBC TSP, relatório contábil de propósito geral, características qualitativas, elementos e reconhecimento. Bases de mensuração de ativos e passivos no setor público e principais normas específicas.

Os editais pedem este assunto assim (cubra todos estes pontos):
- NBC TSP Estrutura Conceitual/2016 e Resolução CFC nº 1.374/2011.
- Norma Brasileira de Contabilidade - NBC TSP Estrutura Conceitual, de 23 de setembro de 2016.
- Transações no setor público.
- Princípios e normas de contabilidade sob a perspectiva do setor público.
- Normas Internacionais de Contabilidade Aplicadas ao Setor Público (IPSAS).
- NBC TSP Estrutura Conceitual – estrutura conceitual para elaboração e divulgação de informação contábil de propósito geral pelas entidades do setor público.
- NBC TSP Estrutura Conceitual - estrutura conceitual para elaboração e divulgação de informação contábil de propósito geral pelas entidades do setor público.
- Relatório Contábil de Propósito Geral das Entidades do Setor Público (RCPG): objetivos e usuários; prestação de contas e responsabilização (accountability) e tomada de decisão; a continuidade das entidades do setor público; situação patrimonial, desempenho e fluxos de caixa; Regime de Competência e Regime de Caixa.
- Características da entidade que reporta a informação contábil.
- Elementos das Demonstrações Contábeis: propósito e definições de ativos e passivos, receitas e despesas; superávit ou déficit do exercício.
- Reconhecimento e mensuração nas demonstrações contábeis: evidenciação, reconhecimento e desreconhecimento; bases de mensuração para ativos e passivo.
- Normas Brasileiras de Contabilidade Aplicadas ao Setor Público - NBC TSP: NBC TSP Estrutura Conceitual;
- NBC TSP 01 a NBC TSP 34.
- Norma Brasileira de Contabilidade NBC TSP: Estrutura Conceitual para Elaboração e Divulgação de Informação Contábil de Propósito Geral pelas Entidades do Setor Público.
- Mensuração e contabilização.
- Mensuração inicial e mensuração subsequente.
- Procedimentos Contábeis Específicos.
- Normas Brasileiras de Contabilidade Aplicadas ao Setor Público – NBC TSP: NBC TSP Estrutura Conceitual.
- NBC TSP 01, NBC TSP 02, NBC TSP 03, NBC TSP 04, NBC TSP 05, NBC TSP 06, NBC TSP 07, NBC TSP 08, NBC TSP 09, NBC TSP 10, NBC TSP 11, NBC TSP 12, NBC TSP 13, NBC TSP 14, NBC TSP 15, NBC TSP 16, NBC TSP 17, NBC TSP 18, NBC TSP 19, NBC TSP 20, NBC TSP 21, NBC TSP 22, NBC TSP 23, NBC TSP 24, NBC TSP 25, NBC TSP 26, NBC TSP 27, NBC TSP 29, NBC TSP 30, NBC TSP 31, NBC TSP 32, NBC TSP 33 e NBC TSP 34.
- Receita e despesa sob o enfoque patrimonial.
- Mensuração de ativos.
- Mensuração de ativos: Ativo imobilizado.
- Mensuração de ativos: Ativo intangível.
- Mensuração de ativos: Reavaliação e redução ao valor recuperável.
- Mensuração de passivos.

## Regras de qualidade (as mais importantes)
1. **Números e dispositivos SÃO o conteúdo.** Cite artigo, lei, súmula, tema e prazo com o número, conferidos no texto oficial vigente (planalto.gov.br, STF, STJ). Nunca escreva "no prazo legal" ou "conforme a lei" quando o número existe. Se não tiver certeza de algum número, explique sem ele — nunca invente.
2. **Teoria:** 5 capítulos, do básico ao avançado, cada um com pelo menos 2.500 caracteres de conteúdo útil (sem enchimento, sem "neste capítulo veremos"). Cada conceito: ideia simples → regra precisa → exemplo concreto do tipo que cai → exceção que a prova usa → como reconhecer. Tabelas para comparar institutos ou casos parecidos. O último capítulo termina com "Como o tema costuma ser cobrado".
3. **Questões: 45** — 25 de múltipla escolha (A a E) e 20 de Certo/Errado; 15 fáceis, 15 médias, 15 difíceis. Gabarito da múltipla escolha com 5 de cada letra; Certo/Errado com 10 de cada. Enunciados com caso concreto, como nas provas.
4. **Tamanho das alternativas:** a certa NÃO pode ser a mais longa nem a mais curta em mais de 10 das 25 questões de múltipla escolha. Escreva as cinco alternativas com tamanho parecido; a certa nunca é uma frase seca de 3 palavras ao lado de distratores longos.
5. **Distratores (o ponto que mais derruba qualidade):** cada alternativa errada é o que um candidato que estudou MAL marcaria — instituto ou conceito vizinho trocado, número, prazo, autor ou súmula trocados, regra certa aplicada ao caso errado, exceção esquecida. Proibido distrator que se elimina sem saber a matéria: absurdo ("toda remoção é impossível", "depende de autorização judicial prévia"), de outro assunto, que contradiz o enunciado, "todas/nenhuma das anteriores", absolutos ("sempre", "nunca", "exclusivamente") só para marcar o errado.
6. **Explicação** de cada questão (mínimo 120 caracteres): por que a certa está certa, com o dispositivo ou a regra, e por que CADA errada erra. Em Certo/Errado começa com "Certo." ou "Errado.".
7. Também: resumo completo; 18 a 25 flashcards (uma ideia por cartão, frente curta, verso de 1 a 3 frases); 5 a 8 dicas práticas; 5 a 8 pegadinhas (como a prova escreve, por que está errado, versão certa); 6 a 10 perguntas de recordação ativa com resposta; **de 4 a 6** "conceitos que geram erro" (chaves e1 a e6); fontes reais que você abriu.
8. Texto neutro: não escreva o nome de nenhuma banca, órgão ou cargo, nem a palavra "banca" (use "a prova").
9. **Fórmulas e figuras (o app desenha exatamente este formato):** toda fórmula em LaTeX entre cifrões DUPLOS (`$$A \cup B$$`; fórmula principal em bloco, com $$ sozinho na linha antes e depois). Nunca use cifrão simples. Gráfico ou figura: um bloco de código com a linguagem `grafico` e um JSON de UMA linha dentro, por exemplo `{"tipo":"barras","titulo":"...","itens":[{"rotulo":"A","valor":3}]}`; tipos: pizza, barras, linha, funcao ({"tipo":"funcao","funcoes":[{"expr":"x^2-4","nome":"f(x)"}],"xmin":-4,"xmax":4}) e geometria ({"tipo":"geometria","pontos":[{"nome":"A","x":0,"y":0}],"circulos":[{"centro":"A","raio":2,"rotulo":"A"}],"segmentos":[{"de":"A","ate":"B","rotulo":"5"}]} — a chave do fim do segmento é "ate", nunca "para"; ponha título e rótulos com os valores do texto, e confira que a figura obedece ao enunciado (ângulo reto onde diz reto) — use círculos para diagramas de Venn). De 1 a 3 por capítulo, quando ajudar. Dentro do JSON da matéria, a barra do LaTeX é dobrada (`\\cup`). Nunca use "|" dentro de fórmula numa linha de tabela.

## Formato de entrega
Um único bloco de código JSON válido, exatamente neste formato (campos e grafia iguais):

```json
{
  "id": "contabilidade-publica.nbc-tsp-estrutura-mensuracao",
  "subject": "Contabilidade Pública",
  "title": "NBC TSP: estrutura conceitual, reconhecimento e mensuração",
  "version": 1,
  "status": "PUBLISHED",
  "aliases": ["NBC TSP: estrutura conceitual, reconhecimento e mensuração"],
  "scope": { "covers": "o que a matéria cobre", "excludes": "o que fica de fora" },
  "theoryTitle": "título completo da teoria",
  "chapters": [ { "title": "1. ...", "markdown": "texto em Markdown (## e ###, listas, **negrito**, tabelas | a | b |, alertas com >)" } ],
  "summary": "resumo em Markdown",
  "flashcards": [ { "front": "pergunta curta", "back": "resposta curta" } ],
  "tips": ["dica 1"],
  "traps": ["pegadinha 1"],
  "activeRecall": [ { "question": "pergunta", "answer": "resposta" } ],
  "errorConcepts": [ { "key": "e1", "title": "nome do erro", "summary": "explicação corretiva" } ],
  "questions": [
    {
      "statement": "enunciado (pergunta ou comando)",
      "format": "MULTIPLE_CHOICE",
      "difficulty": "FACIL",
      "options": [
        { "key": "A", "text": "...", "correct": false },
        { "key": "B", "text": "...", "correct": true },
        { "key": "C", "text": "...", "correct": false },
        { "key": "D", "text": "...", "correct": false },
        { "key": "E", "text": "...", "correct": false }
      ],
      "explanation": "Gabarito B. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": "e1",
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    },
    {
      "statement": "afirmação para julgar",
      "format": "TRUE_FALSE",
      "difficulty": "MEDIA",
      "options": [ { "key": "C", "text": "Certo", "correct": false }, { "key": "E", "text": "Errado", "correct": true } ],
      "explanation": "Errado. ...",
      "section": "título EXATO de um dos capítulos",
      "errorConceptKey": null,
      "sourceType": "AUTHORIAL", "board": null, "agency": null, "year": null, "sourceUrl": null
    }
  ],
  "sources": [ { "kind": "OFICIAL", "title": "...", "publisher": "...", "reference": "...", "url": "https://...", "accessedAt": "AAAA-MM-DD" } ]
}
```
- difficulty: "FACIL", "MEDIA" ou "DIFICIL". format: "MULTIPLE_CHOICE" ou "TRUE_FALSE". kind das fontes: "OFICIAL" ou "COMPLEMENTAR".
- IMPORTANTE: escreva cada explicação de forma própria, à mão. Proibido usar frases-molde repetidas entre questões (ex.: "não descreve o critério aplicável", "A análise deve distinguir..."). Em múltipla escolha, explique por que CADA alternativa errada está errada com o conceito específico dela. Não estique alternativas com enfeites como ", segundo o caso apresentado".
- Antes de entregar, resolva cada questão como candidato: só uma alternativa defensável, gabarito certo, explicação batendo, tamanhos das alternativas equilibrados. Se a resposta ficar longa demais para uma mensagem, entregue em partes, continuando exatamente de onde parou, sem repetir. Se puder, entregue como arquivo .json para download com o nome contabilidade-publica.nbc-tsp-estrutura-mensuracao.json.
